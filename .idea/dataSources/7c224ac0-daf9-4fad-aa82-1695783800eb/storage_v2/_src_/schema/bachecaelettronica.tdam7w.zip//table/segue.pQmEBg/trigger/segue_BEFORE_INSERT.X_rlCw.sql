create definer = root@localhost trigger segue_BEFORE_INSERT
    before insert
    on segue
    for each row
BEGIN
	if exists(select * from `annuncio` where `Utente` = new.`Utente_Username` and `Codice` = new.`Annuncio_Codice`) then
		signal sqlstate '45000' set message_text = 'You can not follow your ad as owner';
	end if;

END;

