create definer = root@localhost trigger avviso_nota
    after insert
    on nota
    for each row
BEGIN
	declare var_username VARCHAR(45);
    declare var_id int;
	declare loop_username INT;
	declare cur_user CURSOR FOR SELECT distinct `Utente_Username` 
    FROM `segue` JOIN `nota` ON `segue`.`Annuncio_Codice` = `nota`.`Annuncio_Codice`;
	declare CONTINUE HANDLER FOR NOT FOUND SET loop_username = 1;
	OPEN cur_user;
	insert_notice: LOOP
		FETCH cur_user INTO var_username;
		select `Annuncio_Codice` into var_id
		from `segue` 
		where `Utente_Username` = var_username;
		IF loop_username = 1 THEN
			LEAVE insert_notice;
		END IF;
   
		INSERT INTO `notifica` (Username_Utente, Data, Testo)
			VALUES (var_username, now(), concat('Hai nuovi aggiornamenti sui tuoi annunci seguiti! Codice annuncio:', var_id)); 
	
    end LOOP insert_notice;
	CLOSE cur_user;
END;

