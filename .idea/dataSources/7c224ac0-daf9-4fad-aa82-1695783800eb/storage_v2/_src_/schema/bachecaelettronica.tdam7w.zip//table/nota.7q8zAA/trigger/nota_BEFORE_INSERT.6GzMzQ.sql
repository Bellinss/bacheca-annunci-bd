create definer = root@localhost trigger nota_BEFORE_INSERT
    before insert
    on nota
    for each row
BEGIN
		if(new.`Annuncio_Codice` not in (select `Codice` from `annuncio` where `Stato` = "Attivo")) then
			signal sqlstate '45000' set message_text = 'You can not follow a sold ad';
		end if;
END;

